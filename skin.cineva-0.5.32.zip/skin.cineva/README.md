# CINÉVA 0.5.0 — Kodi 23 development candidate

CINÉVA is a generic Kodi presentation layer: video add-ons and Kodi library nodes provide content and ListItems; the skin handles presentation and navigation. It does not call Trakt, TMDb or MDBList APIs directly.

## UI and widgets
- Cinematic Home hero changes with the focused shelf item; poster shelves use a light focus zoom and resume progress.
- Separate Home, Movies and TV Shows screens. Each has independent widget settings.
- Home exposes six configurable widget slots (four on the primary home surface, two on a second shelf page).
- Movies and TV Shows each have four independently configurable widget slots.
- Widget sources are selected through the Skin Shortcuts v3 picker, supporting video add-on nodes, Kodi library nodes/sources and playlists.
- POV is only the first-run default: Home gets Continue Watching Movies/TV Shows and Trending Movies/TV Shows; Movies and TV Shows get their corresponding Trending POV default. Users can replace or clear every slot.
- Search source can be selected independently from installed video add-on shortcuts; POV search is the first-run fallback.

## Kodi compatibility
The add-on declares `xbmc.gui` 5.18.0 (Kodi Piers baseline) and Skin Shortcuts 3.x. The supplied user log reported Kodi 23.0 Alpha 1; Kodi 23's skinning changes are documented by Team Kodi.

## Validation status
Static checks cover XML well-formedness, include references, font and texture references, custom window names/IDs, duplicate window IDs, standard window file coverage and ZIP integrity. This container does not have Kodi installed and cannot launch a real Kodi GUI or Fire TV runtime. Therefore this is a **test candidate**, not a runtime-certified final release. Install only if you are comfortable testing a development build; keep your previous skin available.
