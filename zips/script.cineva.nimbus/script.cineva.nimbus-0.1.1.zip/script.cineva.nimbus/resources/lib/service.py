# -*- coding: utf-8 -*-
"""Minimal API-free service entry for Kodi's Nimbus bridge dependency."""
import xbmc


class NimbusBridgeService(xbmc.Monitor):
    def run(self):
        xbmc.log("CINEVA_NIMBUS_BRIDGE_SERVICE_STARTED", xbmc.LOGINFO)
        while not self.abortRequested():
            self.waitForAbort(1)


if __name__ == "__main__":
    NimbusBridgeService().run()
