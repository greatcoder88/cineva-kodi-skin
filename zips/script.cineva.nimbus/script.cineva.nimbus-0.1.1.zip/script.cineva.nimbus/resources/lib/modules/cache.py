# -*- coding: utf-8 -*-
"""Small local cache utilities; intentionally performs no network requests."""
import os
import shutil
import xbmc
import xbmcaddon
import xbmcvfs


def _cache_path():
    addon_id = xbmcaddon.Addon().getAddonInfo("id")
    return xbmcvfs.translatePath(
        "special://profile/addon_data/%s/image_cache" % addon_id
    )


def clear_image_cache():
    path = _cache_path()
    if xbmcvfs.exists(path):
        shutil.rmtree(path, ignore_errors=True)
    xbmcvfs.mkdir(path)
    xbmc.executebuiltin("Notification(CINÉVA, Image cache cleared, 2500)")


def calculate_cache_size():
    path = _cache_path()
    total = 0
    if os.path.isdir(path):
        for base, _dirs, files in os.walk(path):
            for filename in files:
                try:
                    total += os.path.getsize(os.path.join(base, filename))
                except OSError:
                    pass
    megabytes = total / (1024 * 1024)
    xbmc.executebuiltin("Skin.SetString(CinevaCacheSize, %.1f MB)" % megabytes)
    return total
