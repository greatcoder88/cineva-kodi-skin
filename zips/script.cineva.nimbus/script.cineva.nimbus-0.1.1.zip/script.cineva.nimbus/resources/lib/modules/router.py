# -*- coding: utf-8 -*-
"""CINÉVA's API-free compatibility router for Nimbus menu/widget XML."""
import sys
from urllib.parse import parse_qsl


def routing():
    params = dict(parse_qsl(sys.argv[1], keep_blank_values=True))
    mode = params.get("mode", "")

    if mode == "manage_widgets":
        from modules.cpath_maker import CPaths
        return CPaths(params.get("cpath_setting", "")).manage_widgets()
    if mode == "manage_main_menu_path":
        from modules.cpath_maker import CPaths
        return CPaths(params.get("cpath_setting", "")).manage_main_menu_path()
    if mode == "remake_all_cpaths":
        from modules.cpath_maker import remake_all_cpaths
        return remake_all_cpaths()
    if mode in {"refresh_search_history", "search_input", "remove_all_spaths",
                "re_search", "open_search_window", "toggle_search_provider"}:
        from modules.search_utils import SPaths
        action = {
            "refresh_search_history": "refresh_search_history",
            "search_input": "search_input",
            "remove_all_spaths": "remove_all_spaths",
            "re_search": "re_search",
            "open_search_window": "open_search_window",
            "toggle_search_provider": "toggle_search_provider",
        }[mode]
        return getattr(SPaths(), action)()
    if mode in {"set_widget_count", "set_image", "play_trailer",
                "fix_black_screen", "set_blurradius", "set_blursaturation",
                "set_autoendplaybackdelay", "capture_user_key", "modify_keymap",
                "show_changelog"}:
        from modules import custom_actions
        return getattr(custom_actions, mode)()
    if mode in {"clear_image_cache", "calculate_cache_size"}:
        from modules import cache
        return getattr(cache, mode)()
    if mode in {"check_for_update", "check_for_profile_change",
                "set_api_key", "delete_all_ratings", "check_api_key_on_load"}:
        return None
    raise ValueError("Unsupported CINÉVA Nimbus Bridge mode: " + mode)
